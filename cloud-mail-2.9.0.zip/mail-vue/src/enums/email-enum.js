export const EmailUnreadEnum = {
    UNREAD: 0,
    READ: 1
}