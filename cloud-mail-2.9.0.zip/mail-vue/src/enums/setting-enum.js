export const AutoRefreshEnum = {
    DISABLED: 0,
    ENABLED: 1
}