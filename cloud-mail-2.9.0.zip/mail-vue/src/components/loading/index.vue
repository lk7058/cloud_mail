<template>
  <div class="loading-container" :style="{ width: `${size}px`, height: `${size}px` }">
    <div class="loading-spinner">
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
    </div>
  </div>
</template>

<script setup>
import { defineProps } from 'vue';

const props = defineProps({
  size: {
    type: Number,
    default: 30
  }
});
</script>

<style scoped>
.loading-container {
  display: flex;
  align-items: center;
  justify-content: center;
}

.loading-spinner {
  position: relative;
  width: 100%;
  height: 100%;
}

.loading-dot {
  position: absolute;
  width: 20%;
  height: 20%;
  background-color: var(--el-color-primary);
  border-radius: 50%;
  animation: loading-bounce 1.5s infinite ease-in-out both;
}

.loading-dot:nth-child(1) {
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  animation-delay: 0s;
}

.loading-dot:nth-child(2) {
  top: 25%;
  right: 0;
  animation-delay: 0.15s;
}

.loading-dot:nth-child(3) {
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  animation-delay: 0.3s;
}

.loading-dot:nth-child(4) {
  top: 25%;
  left: 0;
  animation-delay: 0.45s;
}

.loading-dot:nth-child(5) {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation-delay: 0.6s;
}

@keyframes loading-bounce {
  0%, 80%, 100% {
    transform: scale(0);
    opacity: 0.3;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}
</style>
