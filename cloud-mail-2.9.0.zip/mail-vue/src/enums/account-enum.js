export const AccountAllReceiveEnum = {
    DISABLED: 0,
    ENABLED: 1
}